package avaliacaods;

import javax.swing.JOptionPane;

public class Gerente {

    public static void main(String[] args) {
           aumento1();
           aumento2();
    }

    String nome;
    double salario;
    double resultado;
    double variavel;

    static void aumento1() {
        double taxa, resultado;
        double salario = Double.parseDouble(JOptionPane.showInputDialog("Insira o seu salario reebido"));
        taxa = salario * 0.1;
        resultado = salario + taxa;
        JOptionPane.showMessageDialog(null, "Seu salario é: " + resultado);
    }

    static void aumento2() {
        double taxa = Double.parseDouble(JOptionPane.showInputDialog("Insira a taxa adcional"));
        double taxatotal;
        double resultado;
        double salario = Double.parseDouble(JOptionPane.showInputDialog("Insira o seu salario recebido"));
        taxatotal = salario * (taxa/100);
        resultado = taxatotal + salario;
        JOptionPane.showMessageDialog(null, "Seu salario é: " + resultado);
    }
}

package avaliacaods;
import javax.swing.JOptionPane;
public class pessoa {

    public static void main(String[] args) {
        imprimir();
    }
    
    static void imprimir() {
        String nome = JOptionPane.showInputDialog("Digite o seu nome");
        String sexo = JOptionPane.showInputDialog("Digite o seu sexo");
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a sua idade"));
        String faixa;
        
        if(idade <= 0) {
            faixa = "Recem Nascido";
        } else if (idade <= 2) {
            faixa = "Bebê";
        } else if (idade <= 11) {
            faixa = "Criança";
        } else if (idade <= 19) {
            faixa = "Adolescente";
        } else if (idade <=30) {
            faixa = "Jovem";
        } else if (idade <= 60) {
           faixa = "Adulto";
        } else {
            faixa = "Idoso";
        }
        
        JOptionPane.showMessageDialog(null, "Nome: " + nome + "\n Idade: " + idade + "\n Sexo: " + sexo + "\n Faixa: " + faixa);
    }

    
}
